const DEFAULT_MODEL = {
  claude: "claude-sonnet-4-6",
  openai: "gpt-4o"
};
const DEFAULT_SETTINGS = {
  githubToken: "",
  aiProvider: "claude",
  aiApiKey: "",
  aiModel: DEFAULT_MODEL.claude,
  responseLanguage: "english",
  outputStyle: "summary",
  prefixPrompt: "",
  uiLanguage: "english"
};
const STORAGE_KEY = "pr_commentor_settings";
async function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(STORAGE_KEY, (result) => {
      const stored = result[STORAGE_KEY];
      resolve({ ...DEFAULT_SETTINGS, ...stored });
    });
  });
}
async function saveSettings(settings) {
  return new Promise((resolve, reject) => {
    chrome.storage.sync.set({ [STORAGE_KEY]: settings }, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve();
      }
    });
  });
}
export {
  DEFAULT_MODEL as D,
  getSettings as g,
  saveSettings as s
};
//# sourceMappingURL=storage-DNbAUzIw.js.map
