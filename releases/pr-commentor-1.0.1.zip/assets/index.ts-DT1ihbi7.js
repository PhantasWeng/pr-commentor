(function(){function parsePRUrl(url) {
  const match = url.match(/github\.com\/([^/]+)\/([^/]+)\/pull\/(\d+)/);
  if (!match) return null;
  return {
    owner: match[1],
    repo: match[2],
    pullNumber: parseInt(match[3], 10)
  };
}
function parseCompareUrl(url) {
  try {
    const u = new URL(url);
    if (u.hostname !== "github.com") return null;
    const m = u.pathname.match(/^\/([^/]+)\/([^/]+)\/compare\/(.+)$/);
    if (!m) return null;
    const compareSpec = m[3];
    const sep = compareSpec.indexOf("...");
    if (sep === -1) return null;
    const base = decodeURIComponent(compareSpec.slice(0, sep));
    const head = decodeURIComponent(compareSpec.slice(sep + 3));
    if (!base || !head) return null;
    return { owner: m[1], repo: m[2], base, head };
  } catch {
    return null;
  }
}
const INJECTED_ATTR = "data-pr-commentor-injected";
function injectButton(toolbar) {
  if (toolbar.hasAttribute(INJECTED_ATTR)) return;
  const textareaId = toolbar.getAttribute("for");
  if (!textareaId) return;
  const textarea = document.getElementById(textareaId);
  if (!textarea) return;
  toolbar.setAttribute(INJECTED_ATTR, "true");
  const button = document.createElement("button");
  button.type = "button";
  button.className = "pr-commentor-btn";
  button.setAttribute("aria-label", "Generate PR Summary");
  button.textContent = "Generate Summary";
  button.addEventListener("click", () => handleClick(button, textarea));
  toolbar.appendChild(button);
}
async function handleClick(button, textarea) {
  var _a;
  const prInfo = parsePRUrl(window.location.href);
  const compareInfo = parseCompareUrl(window.location.href);
  if (!prInfo && !compareInfo) {
    showError$1(textarea, "Could not parse GitHub URL. Make sure you are on a PR or compare page.");
    return;
  }
  if (!((_a = chrome.runtime) == null ? void 0 : _a.id)) {
    showError$1(textarea, "Extension was reloaded — please refresh the page and try again.");
    return;
  }
  button.disabled = true;
  button.textContent = "Generating...";
  button.classList.add("pr-commentor-btn--loading");
  try {
    const payload = prInfo ? { owner: prInfo.owner, repo: prInfo.repo, pullNumber: prInfo.pullNumber } : { owner: compareInfo.owner, repo: compareInfo.repo, base: compareInfo.base, head: compareInfo.head };
    const message = {
      type: "GENERATE_SUMMARY",
      payload
    };
    const response = await chrome.runtime.sendMessage(message);
    if (response.success) {
      insertText(textarea, response.data);
    } else {
      showError$1(textarea, response.error);
    }
  } catch (err) {
    const raw = err instanceof Error ? err.message : "Unknown error occurred";
    const isInvalidated = raw.includes("Extension context invalidated") || raw.includes("message port closed") || raw.includes("Cannot read properties of undefined");
    showError$1(
      textarea,
      isInvalidated ? "Extension was reloaded — please refresh the page and try again." : raw
    );
  } finally {
    button.disabled = false;
    button.textContent = "Generate Summary";
    button.classList.remove("pr-commentor-btn--loading");
  }
}
function insertText(textarea, text) {
  textarea.value = text;
  textarea.dispatchEvent(new Event("input", { bubbles: true }));
  textarea.dispatchEvent(new Event("change", { bubbles: true }));
  textarea.focus();
}
function showError$1(textarea, message) {
  const errorText = `<!-- Error: ${message} -->`;
  textarea.value = errorText;
  textarea.dispatchEvent(new Event("input", { bubbles: true }));
  textarea.focus();
}
const TITLE_INJECTED_ATTR = "data-pr-commentor-title-injected";
const TITLE_SELECTORS = [
  'input[data-component="input"][type="text"]',
  // GitHub React UI (PR edit & compare)
  "input#pull_request_title",
  // Legacy
  'input[name="pull_request[title]"]',
  // Legacy
  'input[name="issue[title]"]',
  // Legacy
  "input.js-issue-title"
  // Legacy
];
function processTitleInputs() {
  for (const sel of TITLE_SELECTORS) {
    document.querySelectorAll(sel).forEach(injectTitleButton);
  }
}
function injectTitleButton(input) {
  if (input.hasAttribute(TITLE_INJECTED_ATTR)) return;
  input.setAttribute(TITLE_INJECTED_ATTR, "true");
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "pr-commentor-btn";
  btn.setAttribute("aria-label", "Generate PR Title");
  btn.textContent = "Generate Title";
  input.insertAdjacentElement("afterend", btn);
  btn.addEventListener("click", () => handleTitleClick(btn, input));
}
async function handleTitleClick(btn, input) {
  var _a;
  const href = window.location.href;
  if (!((_a = chrome.runtime) == null ? void 0 : _a.id)) {
    showError(input, "Extension was reloaded — please refresh the page and try again.");
    return;
  }
  const prInfo = parsePRUrl(href);
  const compareInfo = parseCompareUrl(href);
  if (!prInfo && !compareInfo) {
    showError(input, "Could not parse GitHub URL. Make sure you are on a PR or compare page.");
    return;
  }
  btn.disabled = true;
  btn.textContent = "Generating...";
  btn.classList.add("pr-commentor-btn--loading");
  try {
    const payload = prInfo ? { owner: prInfo.owner, repo: prInfo.repo, pullNumber: prInfo.pullNumber } : { owner: compareInfo.owner, repo: compareInfo.repo, base: compareInfo.base, head: compareInfo.head };
    const message = {
      type: "GENERATE_TITLE",
      payload
    };
    const response = await chrome.runtime.sendMessage(message);
    if (response.success) {
      input.value = response.data.trim();
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      input.focus();
    } else {
      showError(input, response.error);
    }
  } catch (err) {
    const raw = err instanceof Error ? err.message : "Unknown error occurred";
    const isInvalidated = raw.includes("Extension context invalidated") || raw.includes("message port closed") || raw.includes("Cannot read properties of undefined");
    showError(
      input,
      isInvalidated ? "Extension was reloaded — please refresh the page and try again." : raw
    );
  } finally {
    btn.disabled = false;
    btn.textContent = "Generate Title";
    btn.classList.remove("pr-commentor-btn--loading");
  }
}
function showError(input, message) {
  input.title = message;
  input.style.outline = "2px solid red";
  setTimeout(() => {
    input.style.outline = "";
    input.title = "";
  }, 4e3);
}
let observer = null;
let editClickListenerAdded = false;
function processToolbars() {
  document.querySelectorAll("markdown-toolbar").forEach((toolbar) => {
    injectButton(toolbar);
  });
}
function setupEditButtonListener() {
  if (editClickListenerAdded) return;
  editClickListenerAdded = true;
  document.addEventListener("click", (e) => {
    var _a;
    const target = e.target;
    const btn = target.closest("button");
    if (!btn) return;
    const label = btn.querySelector('span[data-component="text"]');
    if (!label || ((_a = label.textContent) == null ? void 0 : _a.trim()) !== "Edit") return;
    setTimeout(processTitleInputs, 150);
  }, { capture: true });
}
function initObserver() {
  processToolbars();
  processTitleInputs();
  setupEditButtonListener();
  if (observer) {
    observer.disconnect();
  }
  observer = new MutationObserver((mutations) => {
    var _a;
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (!(node instanceof Element)) continue;
        if (node.tagName === "MARKDOWN-TOOLBAR") {
          injectButton(node);
        }
        node.querySelectorAll("markdown-toolbar").forEach((toolbar) => {
          injectButton(toolbar);
        });
        for (const sel of TITLE_SELECTORS) {
          if ((_a = node.matches) == null ? void 0 : _a.call(node, sel)) {
            injectTitleButton(node);
          }
          node.querySelectorAll(sel).forEach(injectTitleButton);
        }
      }
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}
function disconnectObserver() {
  observer == null ? void 0 : observer.disconnect();
  observer = null;
}
function init() {
  const href = window.location.href;
  const isPR = /github\.com\/[^/]+\/[^/]+\/pull\/\d+/.test(href);
  const isCompare = /github\.com\/[^/]+\/[^/]+\/compare\//.test(href);
  if (!isPR && !isCompare) return;
  initObserver();
}
init();
document.addEventListener("turbo:load", () => {
  disconnectObserver();
  init();
});
//# sourceMappingURL=index.ts-DT1ihbi7.js.map
})()
